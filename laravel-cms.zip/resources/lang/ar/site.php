<?php
return [
    'Pages' => 'الصفحات',
    'Home' => 'الرئيسية',
    'Profile' => 'الصفحة الشخصية',
    'Settings' => 'الإعدادات',
    'Dashboard'=> 'لوحة التحكم',
    'Login'=>'تسجيل الدخول',
    'Register'=>'تسجيل',
    'Logout'=>'تسجيل الخروج',
    'Latest_comments'=>'اخر التعليقات',
    'Categories'=>'التصنيفات',
    'Confirm_password'=>'تأكيد كلمة المرور',
    'Email_address'=>'عنوان البريد الإلكتروني',
    'Password'=>'كلمة المرور',
    'Name'=>'الإسم',
     
];