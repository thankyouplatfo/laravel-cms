@extends('layouts.app')
@section('content')
<div class="col-lg-8 p-1">
    <div class="container-fluid bg-white">
        <h2 class="display-2">المنشورات</h2>
        <p>
            Eu est cupidatat officia Lorem sint labore amet. Dolore sit et pariatur Lorem dolor culpa
            enim
            ipsum deserunt eu adipisicing mollit. Ea minim proident veniam eiusmod.

            Sint aute commodo reprehenderit qui ut culpa consectetur. Fugiat id reprehenderit pariatur
            consequat anim reprehenderit reprehenderit. Ipsum non nulla velit sit aute. Duis cupidatat
            amet
            duis labore ipsum incididunt sit consequat amet quis fugiat enim ullamco culpa. Culpa
            adipisicing ipsum commodo amet est excepteur ut. Reprehenderit occaecat incididunt Lorem eu
            laborum tempor sunt magna consectetur enim ad. Nulla culpa nulla nisi velit nostrud ea velit
            nostrud pariatur cupidatat mollit tempor veniam.
        </p>
    </div>
</div>
@include('partials.sidebar')
@endsection