<?php

namespace App\Http\Controllers\ViewComposers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Category;
use Illuminate\View\View;

class CtegoryComposer extends Controller
{
    protected $categories;
    //
    public function __construct(Category $categories)
    {
        $this->categories = $categories;
    }
    //
    public function compos()
    {
        # code...
        return $view->with('categories',$this->categories);
    }
}
